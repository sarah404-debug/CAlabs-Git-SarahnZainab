`timescale 1ns / 1ps

module instructionMemory_tb;

    reg [31:0] instAddress;
    wire [31:0] instruction;

    instructionMemory uut (
        .instAddress(instAddress),
        .instruction(instruction)
    );

    initial begin
        instAddress = 0;

        #10 instAddress = 4;
        #10 instAddress = 8;
        #10 instAddress = 12;
        #10 instAddress = 16;
        #10 instAddress = 20;

        #20 $stop;
    end

endmodule