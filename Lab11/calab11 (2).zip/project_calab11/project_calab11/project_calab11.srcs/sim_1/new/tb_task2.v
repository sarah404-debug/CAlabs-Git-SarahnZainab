`timescale 1ns / 1ps

module tb_task2;
    reg clk;
    reg reset;
    reg [15:0] switches;
    wire [15:0] leds;

    // Instantiate Unit Under Test
    TopLevelProcessor uut (
        .clk(clk),
        .reset(reset),
        .switches(switches),
        .leds(leds)
    );

    always #5 clk = ~clk;

    initial begin
        clk = 0;
        reset = 1;
        switches = 16'h0005; // Flip the switch to '5' so the countdown starts!
        
        #15 reset = 0;

        // Run long enough to see the whole countdown loop happen
        #2000;
        $finish;
    end
endmodule